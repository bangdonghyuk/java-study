package com.bang.protectedpackA;

public class ProtectedA {
	protected String name;

	protected void protectedMethod() {
		System.out.println("ProtectedA protectedMethod");
	}

}