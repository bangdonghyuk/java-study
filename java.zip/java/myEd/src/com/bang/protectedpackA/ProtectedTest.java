package com.bang.protectedpackA;

import com.bang.protectedpackC.ProtectedD;

public class ProtectedTest {
	public static void main(String[] args) {
		ProtectedB protectedB = new ProtectedB();
		protectedB.protectedMethod();
		
		ProtectedD protectedD = new ProtectedD();
		protectedD.protectedMethod();
		protectedD.protectedMethod();
		protectedD.protectedMethod();
		protectedD.protectedMethod();
	}

}