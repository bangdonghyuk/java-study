package com.bang.classes;

public class PhoneConstructorTest {
	public static void main(String[] args) {
		Phone phone = new Phone();
	}
}