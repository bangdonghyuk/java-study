package com.bang.classes;

public class MyInfo {
	String name = "ȫ�浿";
	int age = 20;
	String phoneNum = "01011112222";

}