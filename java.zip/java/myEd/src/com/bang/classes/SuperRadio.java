package com.bang.classes;

public class SuperRadio {
	static String comp = "LG";
	static String modelName = "LG_G77";
	static String pInfo;

	static {
		comp = "SAMSUNG";
		pInfo = comp + ":" + modelName;
	}
}
