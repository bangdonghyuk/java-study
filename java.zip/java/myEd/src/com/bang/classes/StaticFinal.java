package com.bang.classes;

public class StaticFinal {
	static final double PI = 3.1415;
	static final int mainSceneID = 100;
	static final int logInSceneID = 200;
	static final int logInSubSceneID = 201;
}
