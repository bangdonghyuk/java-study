package com.bang.classes;

public class RadioStaticTest {
	public static void main(String[] args) {
		
//		System.out.println("Radio.name value is [" + Radio.name + "]");
//		Radio.onQuickRadio();
		

		System.out.println("SuperRadio.pInfo value is [" + SuperRadio.pInfo + "]");
	}
}
