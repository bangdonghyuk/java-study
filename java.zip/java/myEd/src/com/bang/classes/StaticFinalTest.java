package com.bang.classes;

public class StaticFinalTest {
	public static void main(String[] args) {
		StaticFinal staticFinal = new StaticFinal();

		staticFinal.PI = 4.1;
		staticFinal.mainSceneID = 500;
		
	}
}
