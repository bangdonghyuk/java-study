package com.bang.classes;

public class SmartPhone {
	String phoneName = "none";

//	public SmartPhone() {
//		super();
//		phoneName = "myPhone";
//		System.out.println("SmartPhone Constructor is call "
//				+ "phoneName value is "+ phoneName);
//	}
//	

//	public SmartPhone(String name) {
//		phoneName = name;
//
//		System.out.println("SmartPhone Constructor is call " + "phoneName value is " + phoneName);
//	}

	public SmartPhone(String phoneName) {
		super();
		this.phoneName = phoneName;
		System.out.println("SmartPhone Constructor is call " + "phoneName value is " + phoneName);
	}

}
