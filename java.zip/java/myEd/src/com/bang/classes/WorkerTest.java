package com.bang.classes;

public class WorkerTest {
	public static void main(String[] args) {
		System.out.println("------------------Object New---- Start------------------");
		Worker worker = new Worker();
		
		Worker workerTwo = new Worker();
		System.out.println("worker �� workerTwo�� ���� ���� �ٸ� ��ü �Դϴ�.");
		
		System.out.println("----------------Object New----- end------------");
	}
}