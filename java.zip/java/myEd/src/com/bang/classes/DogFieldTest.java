package com.bang.classes;

public class DogFieldTest {
	public static void main(String[] args) {
		Dog dog = new Dog();
		System.out.println("dog.name value is [" + dog.name + "]"); // ���� ���� �� ���.
		System.out.println("dog.gender value is [" + dog.gender + "]");
		System.out.println("dog.age value is [" + dog.age + "]");
		System.out.println("dog.color value is [" + dog.color + "]");
		System.out.println("dog.kind value is [" + dog.kind + "]");
		System.out.println("dog.character value is [" + dog.character + "]");
	}
}

