package com.bang.classes;

public class NotebookFieldTest {
	public static void main(String[] args) {
		Notebook notebook = new Notebook();

		System.out.println("Notebook.name value is [" + notebook.name + "]");
		System.out.println("Notebook.name value is [" + notebook.modelNumber + "]");
		System.out.println("Notebook.name value is [" + notebook.weight + "]");
		System.out.println("Notebook.name value is [" + notebook.color + "]");
		System.out.println("Notebook.name value is [" + notebook.day + "]");
		System.out.println("Notebook.name value is [" + notebook.price + "]");

	}
}
