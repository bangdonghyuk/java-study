package com.bang.classes;

public class Worker {

}
