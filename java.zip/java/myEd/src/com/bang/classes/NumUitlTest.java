package com.bang.classes;

public class NumUitlTest {
	public static void main(String[] args) {
		System.out.println("NumUtil.isEvenOddCal(10) value is [" + NumUtil.isEvenOddCal(10) + "]");
		System.out.println("NumUtil.isEvenOddCal(5) value is [" + NumUtil.isEvenOddCal(5) + "]");

		System.out.println("-------------------------------------------");

		System.out.println("NumUtil.isTwoNumCompare(10, 4) value is [" + NumUtil.isTwoNumCompare(10, 4) + "]");
		System.out.println("NumUtil.isTwoNumCompare(2, 2) value is [" + NumUtil.isTwoNumCompare(2, 2) + "]");
		System.out.println("NumUtil.isTwoNumCompare(10, 20) value is [" + NumUtil.isTwoNumCompare(10, 20) + "]");
	}
}
