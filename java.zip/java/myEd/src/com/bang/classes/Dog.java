package com.bang.classes;

public class Dog {
	String name = "happy";
	String gender = "male";
	int age = 3;
	String color = "white";
	String kind = "yorkshire";
	String character = "activity";
}
