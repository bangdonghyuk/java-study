package com.bang.classes;

public class ConnectUtil {
	private static ConnectUtil connectUtilInstance;

	private ConnectUtil() {
		System.out.println("ConnectUtil Constructor is called.");
	}

	static ConnectUtil getInstance() {
		if (connectUtilInstance == null) {
			connectUtilInstance = new ConnectUtil();
		}
		return connectUtilInstance;
	}
	
	public void connectBank() {
		System.out.println("ConnectBank is OK");
	}

	public void connectBrokerage() {
		System.out.println("ConnectBrokerage is OK");
	}

	
	public void releaseInstance() {
		connectUtilInstance = null;
	}

}
