package com.bang.classes;

public class Notebook {
	String name = "Samsung";
	String modelNumber = "Samsung-77";
	int weight = 150;
	String color = "white";
	String day = "2021.07.26";
	int price = 200000;
}
