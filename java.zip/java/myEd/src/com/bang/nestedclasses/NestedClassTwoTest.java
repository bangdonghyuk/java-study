package com.bang.nestedclasses;

public class NestedClassTwoTest {
	public static void main(String[] args) {
		OutClassExtend outClassExtend = new OutClassExtend();
		outClassExtend.OutClassExtendMethod();
	}

}