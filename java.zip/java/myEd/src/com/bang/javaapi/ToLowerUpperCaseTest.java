package com.bang.javaapi;

public class ToLowerUpperCaseTest {
	public static void main(String[] args) {
		String string = "I'm a boy";

		String toLower = string.toLowerCase();
		String toUpper = string.toUpperCase();

		System.out.println("toLower Value is [" + toLower + "]"); // ��� �ҹ��ڷ�
		System.out.println("toUpper Value is [" + toUpper + "]"); // ��� �빮�ڷ�..
	}

}