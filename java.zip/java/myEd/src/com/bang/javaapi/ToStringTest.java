package com.bang.javaapi;

import java.util.Date;

public class ToStringTest {
	public static void main(String[] args) {
		Object object = new Date();
		System.out.println("object.toString value is ["+object.toString() +"]");
	}

}
