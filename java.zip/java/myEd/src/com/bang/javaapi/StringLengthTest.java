package com.bang.javaapi;

public class StringLengthTest {
	public static void main(String[] args) {
		String phoneNum = "010111185552222";
		
		if(phoneNum.length() == 11 && phoneNum.indexOf("010") == 0) {
			System.out.println("�޴���ȭ");
		} else if(phoneNum.length() == 11 && phoneNum.indexOf("070") == 0) {
			System.out.println("���ͳ���");
		} else if(phoneNum.length() == 9 || phoneNum.length() == 10 && phoneNum.indexOf("02") == 0) {
			System.out.println("����ȭ");
		} else {
			System.out.println("�̰Ź���");
		}
		
		System.out.println("phoneNum.length value is [" + phoneNum.length() + "]");
		System.out.println("phoneNum value is [" + phoneNum + "]");
		
	}
}
