package com.bang.javaapi;

import java.util.StringTokenizer;

public class StringTokenTest {
	public static void main(String[] args) {

		String string = "suji |minsu |sumi |haksun";

		String[] stringsArray = new String[5];

		StringTokenizer stringTokenizer = new StringTokenizer(string, "|");
		int cnt = stringTokenizer.countTokens();

		for (int i = 0; i < cnt; i++) {
			String result = stringTokenizer.nextToken();
			System.out.println(result);
			stringsArray[i] = result;
		}

		for (int j = 0; j < stringsArray.length; j++) {
			System.out.println(stringsArray[j]);
		}
	}
}
