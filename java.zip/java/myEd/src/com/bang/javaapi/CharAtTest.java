package com.bang.javaapi;

public class CharAtTest {
	public static void main(String[] args) {
		String myNation = "korea";
		char outChar = myNation.charAt(4);
		System.out.println("myNation.charAt(2) value is ["+myNation.charAt(3)+"]");
		System.out.println(outChar);
	}
	
}
