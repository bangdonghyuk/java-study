package com.bang.javaapi;

public class Customer {
	public String name;

	public Customer(String name) {
		super();
		this.name = name;
	}


	
}
