package com.bang.nestedinterface;

public class RemoConDetail {
	void devicePowerOff(RemoConExTwo remoConExTwo) { 
		remoConExTwo.devicePowerOff();
	}
}
