package com.bang.nestedinterface;

public class PushListener implements Button.OnClickListener{

	@Override
	public void onClick() {
		// TODO Auto-generated method stub
		System.out.println("PushListener onClick");
	}

}
