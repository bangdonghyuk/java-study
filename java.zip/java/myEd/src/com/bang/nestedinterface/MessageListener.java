package com.bang.nestedinterface;

public class MessageListener implements Button.OnClickListener{

	@Override
	public void onClick() {
		System.out.println("MessaggListener onClick");
	}

}
