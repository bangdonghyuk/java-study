package com.bang.nestedinterface;

public class Anonymous {
	RemoConEx fieldRemoConEx = new RemoConEx() {

		@Override
		public void setOn() {
			// TODO Auto-generated method stub
			System.out.println("Anonymous field Tv Set On");
		}

		@Override
		public void setOff() {
			// TODO Auto-generated method stub
			System.out.println("Anonymous field TV Set Off");
		}
	};

	void method01() {
		RemoConEx localRemoConEx = new RemoConEx() {

			@Override
			public void setOn() {
				// TODO Auto-generated method stub
				System.out.println("Anonymous local Radio Set On");
			}

			@Override
			public void setOff() {
				// TODO Auto-generated method stub
				System.out.println("Anonymous local Radio Set Off");
			}

		};
		localRemoConEx.setOn(); // ���� ������ ���..
	}

	void method02(RemoConEx remoConEx) { // interface�� �Ű� ������ ���� �� �ִ� �޼ҵ�� ���� �Ǿ����ϴ�.
		remoConEx.setOn();
	}

}
