package com.bang.nestedinterface;

public interface RemoConExTwo {

	abstract void devicePowerOff();
	
}
