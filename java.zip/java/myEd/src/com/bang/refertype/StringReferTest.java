package com.bang.refertype;

public class StringReferTest {
	public static void main(String[] args) {
		String sampleA = new String("Lee");

		String sampleB = new String("Lee");

//		if (sampleA == sampleB) {
//			System.out.println("sampleA == sampleB");
//		} else {
//			System.out.println("sampleA != sampleB");
//		}
		
		if (sampleA.equals(sampleB)) { // ���ڿ� �񱳴� �̷��� �մϴ�.
			System.out.println("sampleA sampleB is Same");
		} else {
			System.out.println("sampleA sampleB is Not Same");
		}
	}
}
