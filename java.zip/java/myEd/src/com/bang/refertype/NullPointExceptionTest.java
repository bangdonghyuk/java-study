package com.bang.refertype;

public class NullPointExceptionTest {
	public static void main(String[] args) {
//		String test = new String("ȫ�浿");
		
		String test = "ȫ�浿";
		System.out.println("test value is " + test);
		System.out.println("test length value is " + test.length());
	}

}