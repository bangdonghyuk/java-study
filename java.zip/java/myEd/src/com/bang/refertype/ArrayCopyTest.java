package com.bang.refertype;

public class ArrayCopyTest {
	public static void main(String[] args) {
		String[] aslsMember = { "paul", "json", "alice" };
		String[] toBeMember = new String[10];

		for (int i = 0; i < aslsMember.length; i++) {
			toBeMember[i] = aslsMember[i];
		}

		toBeMember[5] = "��ȣ";

		for (int j = 0; j < toBeMember.length; j++) {
			System.out.println("toBeMember[" + j + "]" + toBeMember[j]);
		}
	}
}
