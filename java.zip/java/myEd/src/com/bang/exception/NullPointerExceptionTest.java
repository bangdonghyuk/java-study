package com.bang.exception;

public class NullPointerExceptionTest {
	public static void main(String[] args) {
//		String stringData = null;
		String stringData = "ABC";
		System.out.println(stringData.toString()); //toString ���ִ�
	}
}
