package com.bang.exception;

public class ArrayInexOutOfBoundsExceptionTest {
	public static void main(String[] args) {
		String[] name = {"suji", "minsu", "jane"};
		
		System.out.println(name[0]);
		System.out.println(name[1]);
		System.out.println(name[2]);
//		System.out.println(name[3]);
	}
}
