package com.bang.protectedpackC;

import com.bang.protectedpackA.ProtectedA;

//import com.bang.protectedpackA.ProtectedA;

public class ProtectedC {
	public String name;

	public void protectedMethod() {
		ProtectedA protectedA = new ProtectedA();
//		protectedA.name = "Pro"; // ���� �Ұ�
//		protectedA.protectedMethod(); // ���� �Ұ�.
	}

}