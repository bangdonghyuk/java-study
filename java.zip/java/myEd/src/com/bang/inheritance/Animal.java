package com.bang.inheritance;

public class Animal {
	String color;

	void walk() {
		System.out.println("[Parents] walking...");
	}

	void eat() {
		System.out.println("[Parents] eating...");
	}

}