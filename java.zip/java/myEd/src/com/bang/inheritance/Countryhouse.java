package com.bang.inheritance;

public class Countryhouse extends House{
	private String name;
	
	
	void baseBallPlay() {
		System.out.println("baseBallPlay");
	}
	
	void rest() {
		System.out.println("forest bathing....");
	}

	@Override
	void sleep() {
		// TODO Auto-generated method stub
		System.out.println("CountrySleep is Sweet"); // ó������ �߰�...
		super.sleep(); // �θ� Method�� ȣ�⵵ ����.
	}
	
	
}
