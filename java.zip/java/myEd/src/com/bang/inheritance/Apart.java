package com.bang.inheritance;

public class Apart extends House {
	private String name;

	void musicPlay() {
		System.out.println("musicPlaying.......");
	}

	void rest() {
		System.out.println("VideoGame Playing....");
	}

}
