package com.bang.inheritance;

public class TigerInheriTest {
	public static void main(String[] args) {
		Tiger tiger = new Tiger();
		tiger.color = "white"; // �θ�� �����Ͽ� ������.
		tiger.walk();
		tiger.eat();
		
		tiger.attack();
		System.out.println("Tiger color is [" + tiger.color + "]");
		tiger.slowWalk();
	}
}
