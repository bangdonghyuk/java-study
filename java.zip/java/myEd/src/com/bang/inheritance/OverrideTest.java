package com.bang.inheritance;

public class OverrideTest {
	public static void main(String[] args) {
		Apart apart = new Apart();

		apart.musicPlay();

		apart.rest();
		
		
		Countryhouse countryhouse = new Countryhouse();
		countryhouse.baseBallPlay();
		countryhouse.rest();
		countryhouse.sleep(); 
	}
}
