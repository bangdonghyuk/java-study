package com.bang.inheritance;

public class House {
	public String name;
	
	void rest() {
		System.out.println("House is rest");
	}
	
	void sleep() {
		System.out.println("House is sleep");
	}
}
