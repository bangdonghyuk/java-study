package com.bang.inheritance;

public class Mouse extends Animal{
	String name = "GGigGGig";
	
	void runAway() {
		System.out.println("Mouse runAway");
	}
}
