package com.bang.inheritance;

public class People {
	public String name;
	
	public People(String name) {
		this.name = name;
		System.out.println("[Parents] People Constructor OK");
	}
}
