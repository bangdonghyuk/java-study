package com.bang.inheritance;

public class SuperKeywordTest {
	public static void main(String[] args) {
		OfficeTel officeTel = new OfficeTel();
		officeTel.eat();
	}
}
