package com.bang.inheritance;

public abstract class SmartPhone {
	public String name;
	
	public SmartPhone(String name) {
		super();
		this.name = name;
	}
	
	public void powerOn(){
		System.out.println("powerOn");
	}
	public void powerOff(){
		System.out.println("powerOff");
	}

	public abstract void bootingLogo();
}
