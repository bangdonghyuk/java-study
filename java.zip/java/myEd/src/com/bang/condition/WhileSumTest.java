package com.bang.condition;

public class WhileSumTest {
	public static void main(String[] args) {
		int count = 0;
		
		while(count < 11) {
			System.out.println(count);
			count++;
		}
	}
	

}