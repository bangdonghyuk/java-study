package com.bang.operator;

public class BinomialOperatorTest {
	public static void main(String[] args) {
		int a = 11;
		int b = 2;
		
		int result01 = a + b;
		int result02 = a - b;
		int result03 = a * b;
		int result04 = a / b;
		int result05 = a % b;
		
		System.out.println("result01 is " + result01);
		System.out.println("result02 is " + result02);
		System.out.println("result03 is " + result03);
		System.out.println("result04 is " + result04);
		System.out.println("result05 is " + result05);
	}
}
