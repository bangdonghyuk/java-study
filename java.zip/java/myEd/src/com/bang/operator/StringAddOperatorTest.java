package com.bang.operator;

public class StringAddOperatorTest {
	public static void main(String[] args) {
		String openSign = "[";
		String closeSign = "]";
		String contentsText = "�츮����� ���ѹα��̴�.";

		System.out.println(openSign + contentsText + closeSign);

		System.out.println("===========" + openSign + contentsText + closeSign + "===========");
	}
}
