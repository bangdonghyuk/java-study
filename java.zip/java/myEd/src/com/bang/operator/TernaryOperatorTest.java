package com.bang.operator;

public class TernaryOperatorTest {
	public static void main(String[] args) {
		int gilDongAge = 18;

		int isAdult = (gilDongAge > 18) ? 30 : 20;// ���ξ�� Ȯ�� ����.....

		System.out.println("gidDong isAdult value is [" + isAdult + "]");
	}
}

