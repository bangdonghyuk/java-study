package com.bang.datatype;

public class BooleanTest {
	public static void main(String[] args) {
	
		boolean isStudent = true;
		

		if (isStudent) {
			System.out.println("�л� �Դϴ�.");
		} else {
			System.out.println("�л��� �ƴմϴ�.");
		}
	}
}