package com.bang.datatype;

public class CastingTestTwo {
	public static void main(String[] args) {
		float inRectRate = 3.14F;

		double outRectRate = (double) inRectRate;
		System.out.println("outRectRate value is [" + outRectRate + "]");
	}

}
