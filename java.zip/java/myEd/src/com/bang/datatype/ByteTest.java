package com.bang.datatype;

public class ByteTest {
	public static void main(String[] args) {
		byte test1 = -128;
		byte test2 = 0;
//		byte test3 = 127;

		System.out.println(test1);
		System.out.println(test2);
	}
}
