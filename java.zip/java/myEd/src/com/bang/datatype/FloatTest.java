package com.bang.datatype;

public class FloatTest {
	public static void main(String[] args) {
		float circumference = 3.14F;
		double circumferenceTwo = 3.14;
		
		System.out.println(circumference);
		System.out.println(circumferenceTwo);
		
	}
}