package com.bang.interfacetest;

public class Tv implements RemoCon {

	@Override
	public void setOn() {
		// TODO Auto-generated method stub
		System.out.println("TvOn");
	}

	@Override
	public void setOff() {
		// TODO Auto-generated method stub
		System.out.println("TvOff");
	}

	
}
