package com.bang.interfacetest;

public interface InputDevice extends PhysicalButton, ScreenTouch, EarPhoneSocket {
	abstract void alertError();
}
