package com.bang.interfacetest;

public class Radio implements RemoCon {

	@Override
	public void setOn() {
		// TODO Auto-generated method stub
		System.out.println("Radio setOn");
	}

	@Override
	public void setOff() {
		// TODO Auto-generated method stub
		System.out.println("Radio setOFF");
	}

	
}