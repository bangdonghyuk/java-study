package com.bang.interfacetest;

public interface EarPhoneSocket {
	abstract void onSound();
}
