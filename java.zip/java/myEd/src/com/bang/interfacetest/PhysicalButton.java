package com.bang.interfacetest;

public interface PhysicalButton {
	abstract void keyPressed();
}
