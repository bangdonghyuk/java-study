package com.bang.interfacetest;

public interface ScreenTouch {
	abstract void onTouch();
}
