package com.bang.access;

public class MyPhoneInfo {
	private String phoneNum = "01011112222";
	private int pw = 1111;
	public String nickName = "happyBoy";

	public void callPhone() {
		System.out.println("call Phone....");
	}

	private void pwModify() {
		System.out.println("pw Modify..");
	}

}